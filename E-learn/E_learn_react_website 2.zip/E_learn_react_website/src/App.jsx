import React, { useState } from 'react'
import Navbar from './Components/Navbar/Navbar'
import Hero from './Components/Hero/Hero'
import Programs from './Components/Programs/Programs'
import Title from './Components/Title/Title'
import About from './Components/About/About'
import Campus from './Components/Campus/Campus'
import Testimonials from './Components/Testimonials/Testimonials'
import  Contact from './Components/Contact/Contact'
import Footer from './Components/Footer/Footer'
import Video from './Components/Videoplayer/video'
const App = () => {
const [playState, setPlayState] = useState(false);

  return (
    <div>
      <Navbar/>
      <Hero/>
      <div className='container'>
        <Title subTitle= 'OUR PROGRAM'  title='What we Offer' />
        <Programs />
        <About setPlayState={setPlayState}/>
        <Title subTitle='Gallery' title='Campus photos' />
        <Campus/>
        <Title subTitle='Testimonials' title='What student says' />
        <Testimonials/>
        <Title subTitle='Contact us' title='Get in Touch' />
        <Contact/>
        <Footer/>
      </div>
      <Video playState={playState} setPlayState={setPlayState}></Video>
    </div>
  )
}

export default App
